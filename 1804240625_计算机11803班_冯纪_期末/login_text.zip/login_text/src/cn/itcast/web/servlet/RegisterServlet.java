package cn.itcast.web.servlet;

import cn.itcast.dao.UserDao;
import cn.itcast.domain.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/registerServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.设置编码
        req.setCharacterEncoding("utf-8");
        //2.获取请求参数
        String id = req.getParameter("id");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        //3.封装user对象
        User registerUser = new User();
        registerUser.setId(Integer.parseInt(id));
        registerUser.setUsername(username);
        registerUser.setPassword(password);

        //4.调用UserDao的register方法
        UserDao dao = new UserDao();
        boolean flag = dao.register(registerUser);
        
        //5.判断user
        if(flag == false)
        {
//            System.out.println(222);
            //注册失败
//            req.getRequestDispatcher("/failServlet").forward(req,resp);
            resp.setContentType("login.html;charset=utf-8");
            resp.getWriter().write("注册失败！");
        }
        else
        {
//            System.out.println(333);
//            //注册成功
//            //存储数据
//            req.setAttribute("user",user);
////            //转发
//            req.getRequestDispatcher("/successServlet").forward(req,resp);
            resp.setContentType("login.html;charset=utf-8");
//            resp.getWriter().write("注册成功！");
            req.getRequestDispatcher("/login.html").forward(req,resp);
        }
    }
}
