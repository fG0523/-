package cn.itcast.test;

import cn.itcast.dao.UserDao;
import cn.itcast.domain.User;
import org.junit.Test;

public class UserDaoTest {
    @Test
    public void testLogin(){
        User loginuser = new User();
        loginuser.setUsername("superbaby");
        loginuser.setPassword("1234312432");

        UserDao dao = new UserDao();
        User user = dao.login(loginuser);
        System.out.println(user);
    }
    @Test
    public void testregister(){
        User registeruser = new User();

        registeruser.setUsername("12345");
        registeruser.setPassword("12345");

        UserDao dao = new UserDao();
        boolean flag = dao.register(registeruser);
        System.out.println(flag);
    }
}
